@yield('php')
@php
    $user = session()->get('user');
    $roles = [];
    foreach ($user->roles as $role) {
        $roles[] = $role->id;
    }
@endphp
@if (!in_array($roleId, $roles))
    @component('unauthorized', [
        'error' => '403',
        'errorMessage' => 'Forbidden',
        'message' => ' không có quyền truy cập trang web này',
    ])
    @endcomponent
@else
    @yield('layout')
@endif
