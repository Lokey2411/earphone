<li class="nav-item {{ hasRole($roleId) ? '' : 'd-none' }}">
    <a class="nav-link {{ str_contains(URL::full(), '/' . $route) ? 'text-primary' : '' }}"
        href="{{ route('show.' . $route) }}">
        <span data-feather="file"></span>
        {{ $displayText }}
    </a>
</li>
