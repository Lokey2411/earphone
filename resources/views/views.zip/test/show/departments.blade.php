@extends('components.layout')
@section('php')
    @php
        $roleId = 1;
    @endphp
@endsection
@section('title', 'Danh sách bộ phận')
@section('add-link', route('add.department'))
@section('table')
    @component('components.react-component', ['componentName' => 'MyComponent'])
    @endcomponent
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên</th>
                <th>Địa chỉ</th>
                <th>Thời gian mở cửa</th>
                <th>Thời gian đóng cửa</th>
                <th>Người sở hữu</th>
                <th>Kiểu bộ phận</th>
                <th>Bộ phận trực thuộc</th>
                <th scope="col">Thao tác</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($departments as $department)
                <tr>

                    <td>{{ $department->id }}</td>
                    <td>{{ $department->name }}</td>
                    <td>{{ $department->address }}</td>
                    <td>{{ $department->openTime }}</td>
                    <td>{{ $department->closeTime }}</td>
                    <td>{{ $department->owner->username }}</td>
                    <td>{{ $department->type }}</td>
                    <td>{{ $department->parentDepartment->name }}</td>
                    <td colspan="2">
                        <a href="{{ route('edit.department', $department->id) }}" class="btn btn-primary btn-hover">Sửa</a>
                        <button class="btn btn-danger" onclick="showConfirmModel({{ $department->id }})">Xóa</button>
                        {{-- delete model --}}
                        @component('components.delete-confirm', [
                            'confirmId' => $department->id,
                            'confirmMessage' => 'Bạn có muốn xóa bộ phận này?',
                            'confirmAction' => route('departments.destroy', $department->id),
                        ])
                        @endcomponent
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $departments->links('components.pagination') }}
@endsection
