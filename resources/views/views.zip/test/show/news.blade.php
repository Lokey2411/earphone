@extends('components.layout')
@section('php')
    @php
        $roleId = 3;
    @endphp
@endsection
@section('title', 'Danh sách Tin tức')
@section('add-link', route('add.news'))
@section('table')
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th>ID</th>
                <th>Thuộc bộ phận</th>
                <th>Thời gian</th>
                <th>Tiêu đề</th>
                <th>Đề mục</th>
                <th>Mô tả</th>
                <th>Kiểu</th>
                <th>Đường link</th>
                <th scope="col">Thao tác</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($news as $n)
                <tr>
                    <td>{{ $n->id }}</td>
                    <td>{{ $n->department->name }}</td>
                    <td>{{ $n->time }}</td>
                    <td>{{ $n->title }}</td>
                    <td>{{ $n->subtitle }}</td>
                    <td style="width: 300px">{{ Str::substr($n->description, 0, 100) }}</td>
                    <td>{{ $n->type }}</td>
                    <td>{{ $n->parent }}</td>
                    <td colspan="2">
                        <a href="{{ route('edit.news', $n->id) }}" class="btn btn-primary btn-hover">Sửa</a>
                        <button class="btn btn-danger" onclick="showConfirmModel({{ $n->id }})">Xóa</button>
                        {{-- delete model --}}
                        @component('components.delete-confirm', [
                            'confirmId' => $n->id,
                            'confirmMessage' => 'Bạn có muốn xóa tin tức này?',
                            'confirmAction' => route('news.destroy', $n->id),
                        ])
                        @endcomponent
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $news->links('components.pagination') }}
@endsection
