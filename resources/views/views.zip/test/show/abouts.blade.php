@extends('components.layout')
@section('php')
    @php
        $roleId = 6;
    @endphp
@endsection
@section('title', 'Nội dung trang web')
@section('add-link', route('add.about'))
@section('table')
    @if (isset($_GET['page']))
        @php
            $abouts = $abouts[$_GET['page']];
        @endphp

        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Đề mục</th>
                    <th>Trang hiển thị</th>
                    <th scope="col">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($abouts as $about)
                    <tr>

                        <td>{{ $about->id }}</td>
                        <td>{{ Str::substr($about->title, 0, 100) }}...</td>
                        <td>{{ $about->subtitle }}</td>
                        <td>https://thanhcoffee.com/{{ $about->parent }}</td>
                        <td colspan="2">
                            <a href="{{ route('edit.about', $about->id) }}" class="btn btn-primary btn-hover">Sửa</a>
                            <button class="btn btn-danger" onclick="showConfirmModel({{ $about->id }})">Xóa</button>
                            {{-- delete model --}}
                            @component('components.delete-confirm', [
                                'confirmId' => $about->id,
                                'confirmMessage' => 'Bạn có muốn xóa nội dung này?',
                                'confirmAction' => route('abouts.destroy', $about->id),
                            ])
                            @endcomponent
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <!-- Search Input -->
        <label for="searchInput" class="tw-text-xl tw-font-bold">Không biết phải update vào trang nào? paste đường link vào
            đây:</label>
        <input type="text" id="searchInput" placeholder="Search..."
            class="tw-mb-4 tw-p-2 tw-border tw-rounded-lg tw-w-full tw-text-lg">
        <div class="tw-grid tw-grid-cols-3 tw-gap-4 tw-p-2" id="aboutItems">
            @php
                $keys = [];
                foreach ($abouts as $key => $value) {
                    $keys[] = $key;
                }
            @endphp
            <!-- Container for the filtered items -->
            @foreach ($keys as $index => $key)
                @php
                    $backgroundColor = '#' . str_pad(dechex(mt_rand(0, 0xffffff)), 6, '0', STR_PAD_LEFT);
                @endphp
                <a href="?page={{ $key }}" class="tw-block tw-resize-x tw-rounded-lg tw-overflow-hidden about-item"
                    style="background : url('{{ $abouts[$key][0]->image }}') top center /cover no-repeat">
                    <div
                        class="tw-rounded-md tw-px-2 tw-py-3 tw-overflow-hidden tw-relative tw-h-20 tw-cursor-pointer tw-flex tw-justify-center tw-items-start">
                        <p class="tw-text-xl tw-font-bold tw-w-full tw-overflow-hidden tw-text-white tw-z-10">
                            https://thanhcoffee.com/{{ $key }}</p>
                        <div
                            class="tw-absolute tw-top-0 tw-bottom-0 tw-left-0 tw-right-0 tw-inset-0 tw-bg-black tw-opacity-40 tw-rounded-lg">
                        </div>
                        <p class="tw-text-3xl tw-font-bold tw-text-right tw-text-white tw-absolute tw-right-2 tw-bottom-2">
                            {{ $abouts[$key]->count() }}</p>
                    </div>
                </a>
            @endforeach
            <div id="notFoundBox" class="tw-mt-3 tw-flex tw-flex-col tw-hidden">
                <p class="tw-text-green-600 tw-font-bold tw-text-2xl tw-mb-3">Không tìm thấy trang web?</p>
                <a href="{{ route('add.about') }}"
                    class="tw-bg-blue-500 tw-text-white tw-p-2 tw-rounded bg-blue-500 text-white rounded p-2 tw-mt-3">
                    Hãy thêm nó
                </a>
            </div>
            <!-- JavaScript for filtering -->
            <script>
                document.getElementById('searchInput').addEventListener('input', function() {
                    const query = this.value.toLowerCase();
                    const items = document.querySelectorAll('.about-item');
                    const hiddenItem = document.querySelector("#notFoundBox");
                    items.forEach(function(item) {
                        const text = item.querySelector('p').textContent.toLowerCase().trim();
                        let countItem = 0;
                        if (text.includes(query) || query.startsWith(text)) {
                            item.style.display = 'block';
                            countItem++;
                        } else {
                            item.style.display = 'none';
                        }
                        if (countItem > 0) {
                            hiddenItem.style.display = "none";
                        } else {
                            hiddenItem.style.display = "block";
                        }
                    });
                });
            </script>

        </div>
        <p class="tw-text-gray-300 tw-italic tw-text-xl">Note: Số hiển thị phía dưới là những nội dung đã được thêm
            vào</p>
    @endif
@endsection
